//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CG_x.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_CG_XTYPE                    129
#define ID_Menu_31_CPen                 32771
#define ID_Menu_32_CBrush               32772
#define ID_MENU_33_MouseSprint          32773
#define ID_MENU_341_DDAOnDraw           32775
#define ID_MENU_342_FangDa10            32776
#define ID_MENU_343_MouseLine           32777
#define ID_MENU_CLEARALL                32778
#define ID_MENU_35_PEN                  32779
#define ID_MENU_461_MidpointCircle      32780
#define ID_MENU_462_MidpointEllise      32781
#define ID_MENU_COLOR                   32782
#define ID_MENU_51_SpeedFill            32783
#define ID_MENU_52_SpeedFill_Zhongzi    32784
#define ID_MENU_611_LINE                32785
#define ID_MENU_612_CRICLE              32786
#define ID_MENU_621_LINE                32787
#define ID_MENU_622_CRICLE              32788
#define ID_MENU_37_DOTLINE              32789
#define ID_MENU_71_Mouse_Code_Clip      32790
#define ID_MENU_81_Par                  32791
#define ID_MENU_82_Hermite              32792
#define ID_MENU_83_Bezier               32793
#define ID_MENU_84_Bezier3              32794
#define ID_MENU_85_3ByangtaoLine        32795
#define ID_MENU_CHANGE_pingyi           32796
#define ID_MENU_CHANGE_XUANXZHUAN       32797
#define ID_MENU_CHANGE_FANGDASUOXIAO    32798
#define ID_MENU_Other_Flowers           32799
#define ID_MENU_OTHERS_JIAOHUSHIYIDONGTUXING 32800

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32801
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
